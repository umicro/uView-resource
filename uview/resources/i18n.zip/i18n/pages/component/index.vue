<template>
	<view class="content">
		<image class="logo" src="/static/uview/common/logo.png"></image>
		<view class="text-area u-m-b-60">
			<text class="title">{{$t('component.desc')}}</text>
		</view>
		<u-button @click="switchLang" throttleTime="200">切换语言</u-button>
	</view>
</template>

<script>
	export default {
		onShow() {
			uni.setNavigationBarTitle({
				title: this.$t('tabbar.component')
			});
		},
		methods: {
			switchLang() {
				this.$i18n.locale = this.$i18n.locale == 'en' ? 'cn' : 'en';
				uni.setNavigationBarTitle({
					title: this.$t('tabbar.component')
				});
				// 注意：【支付宝小程序开发工具】需要1.13版本才支持此接口的模拟，真机预览不受限制
				uni.setTabBarItem({
					index: 0,
					text: this.$t('tabbar.component'),
					iconPath: "/static/uview/example/component.png",
					selectedIconPath: "/static/uview/example/component_select.png",
				})
				uni.setTabBarItem({
					index: 1,
					text: this.$t('tabbar.js'),
					iconPath: "/static/uview/example/js.png",
					selectedIconPath: "/static/uview/example/js_select.png",
				})
				uni.setTabBarItem({
					index: 2,
					text: this.$t('tabbar.template'),
					iconPath: "/static/uview/example/template.png",
					selectedIconPath: "/static/uview/example/template_select.png",
				})
			}
		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;
	}
</style>
